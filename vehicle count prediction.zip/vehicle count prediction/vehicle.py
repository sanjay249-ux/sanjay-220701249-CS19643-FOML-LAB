import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load dataset
train = pd.read_csv(r"C:\Users\lokes\OneDrive\Desktop\MSSQL16.MSSQLSERVER\ml project\vehicle count prediction\vehicles.csv")

# Convert DateTime to datetime object
train['DateTime'] = pd.to_datetime(train['DateTime'])

# Feature extraction from datetime
train['date'] = train['DateTime'].dt.day
train['weekday'] = train['DateTime'].dt.weekday
train['hour'] = train['DateTime'].dt.hour
train['month'] = train['DateTime'].dt.month
train['year'] = train['DateTime'].dt.year
train['dayofyear'] = train['DateTime'].dt.dayofyear
train['weekofyear'] = train['DateTime'].dt.isocalendar().week.astype(int)

# Drop original DateTime
train = train.drop(['DateTime'], axis=1)

# Separate features and target
X = train.drop(['Vehicles'], axis=1)
y = train['Vehicles']

# Model training
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Prediction
y_pred = model.predict(X)

# Evaluation metrics
mae = mean_absolute_error(y, y_pred)
mse = mean_squared_error(y, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y, y_pred)

print(f"Mean Absolute Error: {mae:.2f}")
print(f"Mean Squared Error: {mse:.2f}")
print(f"Root Mean Squared Error: {rmse:.2f}")
print(f"R² Score: {r2:.2f}")

# Plot Actual vs Predicted
plt.figure(figsize=(10,6))
plt.scatter(y, y_pred, alpha=0.3)
plt.xlabel('Actual Vehicle Count')
plt.ylabel('Predicted Vehicle Count')
plt.title('Actual vs Predicted Vehicle Count')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')
plt.show()

# Feature Importance
feat_importances = pd.Series(model.feature_importances_, index=X.columns)
feat_importances.nlargest(7).plot(kind='barh', title='Feature Importances')
plt.show()

# Residual plot
residuals = y - y_pred
plt.figure(figsize=(10,5))
sns.histplot(residuals, bins=30, kde=True)
plt.title("Residuals Distribution")
plt.xlabel("Residual")
plt.ylabel("Frequency")
plt.show()
